import { Routes, Route, Link } from 'react-router-dom';
import MusicaList from "./components/MusicaList";
import MusicaForm from "./components/MusicaForm";

function App() {
  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      {/* Menu de navegação */}
      <nav style={{ marginBottom: '20px' }}>
        <Link to="/" style={{ marginRight: '15px' }}>🎵 Músicas</Link>
        <Link to="/musicas/nova">➕ Nova Música</Link>
      </nav>
      
      <Routes>
        {/* Rotas para Músicas */}
        <Route path="/" element={<MusicaList />} />
        <Route path="/musicas" element={<MusicaList />} />
        <Route path="/musicas/nova" element={<MusicaForm />} />
        <Route path="/musicas/editar/:id" element={<MusicaForm />} />
        
      </Routes>
      
      <footer style={{ 
        marginTop: '40px', 
        textAlign: 'center', 
        color: '#666',
        padding: '20px',
        borderTop: '1px solid #eee'
      }}>
        <p>Sistema Integrado - {new Date().getFullYear()}</p>
      </footer>
    </div>
  );
}

export default App;
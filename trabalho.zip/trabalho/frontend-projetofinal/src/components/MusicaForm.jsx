import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import api from '../services/api';

function MusicaForm() {
    const navigate = useNavigate();
    const { id } = useParams();
    
    const [musica, setMusica] = useState({
        titulo: '',
        artista: '',
        album: '',
        genero: '',
        duracao: '',
        anoLancamento: '',
        capaUrl: ''
    });

    // Carregar música se estiver editando
    useEffect(() => {
        if (id) {
            api.get(`/api/musicas/${id}`)
                .then(response => {
                    setMusica(response.data);
                })
                .catch(error => {
                    alert("Erro ao buscar dados para edição.");
                    navigate('/');
                    console.error(error);
                });
        }
    }, [id, navigate]);

    const handleChange = (event) => {
        const { name, value } = event.target;
        setMusica({ ...musica, [name]: value });
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        
        try {
            if (id) {
                // SE TEM ID -> É EDIÇÃO (PUT)
                await api.put(`/api/musicas/${id}`, musica);
                alert('Música atualizada com sucesso!');
            } else {
                // SE NÃO TEM ID -> É CRIAÇÃO (POST)
                await api.post('/api/musicas', musica);
                alert('Música cadastrada com sucesso!');
            }
            navigate('/'); // Volta para a lista
        } catch (error) {
            console.error(error);
            alert('Erro ao salvar música.');
        }
    };

    return (
        <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto' }}>
            <h2>{id ? 'Editar Música' : 'Nova Música'}</h2>
            
            <form onSubmit={handleSubmit}>
                {/* Campo Título */}
                <div style={{ marginBottom: '15px' }}>
                    <label>Título: *</label><br/>
                    <input
                        type="text"
                        name="titulo"
                        value={musica.titulo}
                        onChange={handleChange}
                        required
                        style={{ width: '100%', padding: '8px' }}
                    />
                </div>

                {/* Campo Artista */}
                <div style={{ marginBottom: '15px' }}>
                    <label>Artista: *</label><br/>
                    <input
                        type="text"
                        name="artista"
                        value={musica.artista}
                        onChange={handleChange}
                        required
                        style={{ width: '100%', padding: '8px' }}
                    />
                </div>

                {/* Campo Álbum */}
                <div style={{ marginBottom: '15px' }}>
                    <label>Álbum:</label><br/>
                    <input
                        type="text"
                        name="album"
                        value={musica.album}
                        onChange={handleChange}
                        style={{ width: '100%', padding: '8px' }}
                    />
                </div>

                {/* Campo Gênero */}
                <div style={{ marginBottom: '15px' }}>
                    <label>Gênero: *</label><br/>
                    <select
                        name="genero"
                        value={musica.genero}
                        onChange={handleChange}
                        style={{ width: '100%', padding: '8px' }}
                    >
                        <option value="Pop">Pop</option>
                        <option value="Rock">Rock</option>
                        <option value="Hip Hop">Hip Hop</option>
                        <option value="Jazz">Jazz</option>
                        <option value="Eletrônica">Eletrônica</option>
                        <option value="MPB">MPB</option>
                        <option value="Sertanejo">Sertanejo</option>
                        <option value="Funk">Funk</option>
                        <option value="Outro">Outro</option>
                    </select>
                </div>

                {/* Campos em linha */}
                <div style={{ display: 'flex', gap: '15px', marginBottom: '15px' }}>
                    <div style={{ flex: 1 }}>
                        <label>Duração (segundos):</label><br/>
                        <input
                            type="number"
                            name="duracao"
                            value={musica.duracao}
                            onChange={handleChange}
                            style={{ width: '100%', padding: '8px' }}
                        />
                    </div>
                    
                    <div style={{ flex: 1 }}>
                        <label>Ano de Lançamento:</label><br/>
                        <input
                            type="number"
                            name="anoLancamento"
                            value={musica.anoLancamento}
                            onChange={handleChange}
                            style={{ width: '100%', padding: '8px' }}
                            min="1900"
                            max={new Date().getFullYear()}
                        />
                    </div>
                </div>

                {/* Campo URL da Capa */}
                <div style={{ marginBottom: '20px' }}>
                    <label>URL da Capa do Álbum:</label><br/>
                    <input
                        type="url"
                        name="capaUrl"
                        value={musica.capaUrl}
                        onChange={handleChange}
                        style={{ width: '100%', padding: '8px' }}
                        placeholder="https://exemplo.com/capa.jpg"
                    />
                </div>

                {/* Ações */}
                <div style={{ marginTop: '20px' }}>
                    <button 
                        type="button" 
                        onClick={() => navigate('/')} 
                        style={{ marginRight: '10px', padding: '10px 20px' }}
                    >
                        Cancelar
                    </button>
                    <button 
                        type="submit"
                        style={{ padding: '10px 20px' }}
                    >
                        {id ? 'Salvar Alterações' : 'Cadastrar Música'}
                    </button>
                </div>
            </form>
        </div>
    );
}

export default MusicaForm;
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';

function MusicaList() {
    const [musicas, setMusicas] = useState([]);
    const [busca, setBusca] = useState('');
    const [filtroGenero, setFiltroGenero] = useState('todos');

    useEffect(() => {
        const carregarMusicas = async () => {
            try {
                const response = await api.get('/api/musicas');
                setMusicas(response.data);
            } catch (error) {
                console.error("Erro:", error);
                alert("Erro ao carregar a lista de músicas.");
            }
        };
        carregarMusicas();
    }, []);

    // Filtrar músicas
    const musicasFiltradas = musicas.filter(musica => {
        const matchBusca = musica.titulo.toLowerCase().includes(busca.toLowerCase()) ||
                          musica.artista.toLowerCase().includes(busca.toLowerCase()) ||
                          musica.album.toLowerCase().includes(busca.toLowerCase());
        const matchGenero = filtroGenero === 'todos' || musica.genero === filtroGenero;
        return matchBusca && matchGenero;
    });

    // Função de Excluir
    const excluirMusica = async (id) => {
        if (confirm("Tem certeza que deseja excluir esta música?")) {
            try {
                await api.delete(`/api/musicas/${id}`);
                setMusicas(musicas.filter(musica => musica.id !== id));
                alert('Música excluída com sucesso!');
            } catch (error) {
                console.error("Erro:", error);
                alert("Erro ao excluir.");
            }
        }
    };

    // Formatar duração
    const formatarDuracao = (segundos) => {
        if (!segundos) return '0:00';
        const minutos = Math.floor(segundos / 60);
        const segs = segundos % 60;
        return `${minutos}:${segs < 10 ? '0' : ''}${segs}`;
    };

    return (
        <div style={{ padding: '20px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px' }}>
                <h2>Biblioteca de Música</h2>
                <Link to="/cadastro">
                    <button>+ Adicionar Música</button>
                </Link>
            </div>

            {/* Filtros */}
            <div style={{ marginBottom: '20px', display: 'flex', gap: '10px' }}>
                <input
                    type="text"
                    placeholder="Buscar música, artista ou álbum..."
                    value={busca}
                    onChange={(e) => setBusca(e.target.value)}
                    style={{ flex: 1, padding: '10px' }}
                />
                
                <select
                    value={filtroGenero}
                    onChange={(e) => setFiltroGenero(e.target.value)}
                    style={{ padding: '10px' }}
                >
                    <option value="todos">Todos os gêneros</option>
                    <option value="Pop">Pop</option>
                    <option value="Rock">Rock</option>
                    <option value="Hip Hop">Hip Hop</option>
                    <option value="Jazz">Jazz</option>
                    <option value="Eletrônica">Eletrônica</option>
                    <option value="Outro">Outro</option>
                </select>
            </div>

            {/* Tabela */}
            <table border="1" style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                    <tr style={{ backgroundColor: '#f2f2f2' }}>
                        <th style={{ padding: '10px', textAlign: 'left' }}>Capa</th>
                        <th style={{ padding: '10px', textAlign: 'left' }}>Título</th>
                        <th style={{ padding: '10px', textAlign: 'left' }}>Artista</th>
                        <th style={{ padding: '10px', textAlign: 'left' }}>Álbum</th>
                        <th style={{ padding: '10px', textAlign: 'left' }}>Gênero</th>
                        <th style={{ padding: '10px', textAlign: 'left' }}>Duração</th>
                        <th style={{ padding: '10px', textAlign: 'left' }}>Ano</th>
                        <th style={{ padding: '10px', textAlign: 'left' }}>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    {musicasFiltradas.map((musica) => (
                        <tr key={musica.id}>
                            <td style={{backgroundColor :'#f2f2f2', padding: '10px', }}>
                                {musica.capaUrl && (
                                    <img 
                                        src={musica.capaUrl} 
                                        alt={musica.titulo}
                                        style={{ width: '50px', height: '50px', objectFit: 'cover' }}
                                        onError={(e) => {
                                            e.target.style.display = 'none';
                                            e.target.parentElement.innerHTML = '📀';
                                        }}
                                    />
                                )}
                            </td>
                            <td style={{backgroundColor :'#f2f2f2', padding: '10px' }}>{musica.titulo}</td>
                            <td style={{backgroundColor :'#f2f2f2', padding: '10px' }}>{musica.artista}</td>
                            <td style={{backgroundColor :'#f2f2f2', padding: '10px' }}>{musica.album || '-'}</td>
                            <td style={{backgroundColor :'#f2f2f2', padding: '10px' }}>
                                <span style={{
                                    backgroundColor: '#ffffff',
                                    padding: '3px 8px',
                                    borderRadius: '12px',
                                    fontSize: '0.85em'
                                }}>
                                    {musica.genero}
                                </span>
                            </td>
                            <td style={{backgroundColor :'#f2f2f2', padding: '10px' }}>{formatarDuracao(musica.duracao)}</td>
                            <td style={{backgroundColor :'#f2f2f2', padding: '10px' }}>{musica.anoLancamento || '-'}</td>
                            <td style={{backgroundColor :'#f2f2f2', padding: '10px' }}>
                                <button
                                    onClick={() => excluirMusica(musica.id)}
                                    style={{ backgroundColor: '#f33838' }}
                                >
                                    Excluir
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>

            {musicasFiltradas.length === 0 && (
                <div style={{ textAlign: 'center', padding: '40px', color: '#666' }}>
                    {busca || filtroGenero !== 'todos' 
                        ? 'Nenhuma música encontrada com os filtros atuais.'
                        : 'Nenhuma música cadastrada. Adicione sua primeira música!'}
                </div>
            )}

            <div style={{ marginTop: '20px', color: '#666' }}>
                Mostrando {musicasFiltradas.length} de {musicas.length} músicas
            </div>
        </div>
    );
}

export default MusicaList;
package com.primeiroapi.primeiraapi;

public @interface SpringBootTest {

}

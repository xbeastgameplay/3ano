package com.primeiraapi.model;

import jakarta.persistence.*;

@Entity
@Table(name = "musicas")
public class Musica {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String titulo;
    
    @Column(nullable = false)
    private String artista;
    
    private String album;
    
    @Column(nullable = false)
    private String genero;
    
    private int duracao; // em segundos
    
    private String capaUrl;
    
    @Column(name = "ano_lancamento")
    private Integer anoLancamento;
    
    private boolean favorita;
    
    // Construtores
    public Musica() {
    }
    
    public Musica(String titulo, String artista, String genero) {
        this.titulo = titulo;
        this.artista = artista;
        this.genero = genero;
    }
    
    // Getters e Setters
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public String getTitulo() {
        return titulo;
    }
    
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    
    public String getArtista() {
        return artista;
    }
    
    public void setArtista(String artista) {
        this.artista = artista;
    }
    
    public String getAlbum() {
        return album;
    }
    
    public void setAlbum(String album) {
        this.album = album;
    }
    
    public String getGenero() {
        return genero;
    }
    
    public void setGenero(String genero) {
        this.genero = genero;
    }
    
    public int getDuracao() {
        return duracao;
    }
    
    public void setDuracao(int duracao) {
        this.duracao = duracao;
    }
    
    public String getCapaUrl() {
        return capaUrl;
    }
    
    public void setCapaUrl(String capaUrl) {
        this.capaUrl = capaUrl;
    }
    
    public Integer getAnoLancamento() {
        return anoLancamento;
    }
    
    public void setAnoLancamento(Integer anoLancamento) {
        this.anoLancamento = anoLancamento;
    }
    
    public boolean isFavorita() {
        return favorita;
    }
    
    public void setFavorita(boolean favorita) {
        this.favorita = favorita;
    }
}
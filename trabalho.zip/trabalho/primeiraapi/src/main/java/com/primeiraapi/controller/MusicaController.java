package com.primeiraapi.controller;

import com.primeiraapi.model.Musica;
import com.primeiraapi.service.MusicaService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/musicas")
public class MusicaController {
    
    private final MusicaService musicaService;
    
    // Injeção via construtor (mais recomendado)
    public MusicaController(MusicaService musicaService) {
        this.musicaService = musicaService;
    }
    
    @GetMapping
    public ResponseEntity<?> listarTodos() {
        List<Musica> musicas = musicaService.findAll();
        return ResponseEntity.ok(musicas);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Musica> getMusicaById(@PathVariable Long id) {
        return musicaService.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    @PostMapping
    public ResponseEntity<Musica> createMusica(@RequestBody Musica musica) {
        Musica savedMusica = musicaService.save(musica);
        return ResponseEntity.ok(savedMusica);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Musica> updateMusica(@PathVariable Long id, @RequestBody Musica musicaDetails) {
        return musicaService.findById(id)
                .map(musica -> {  // Correção: 'musica' em minúsculo
                    musica.setTitulo(musicaDetails.getTitulo());
                    musica.setArtista(musicaDetails.getArtista());
                    musica.setAlbum(musicaDetails.getAlbum());
                    musica.setGenero(musicaDetails.getGenero());
                    musica.setDuracao(musicaDetails.getDuracao());
                    musica.setCapaUrl(musicaDetails.getCapaUrl());
                    musica.setAnoLancamento(musicaDetails.getAnoLancamento());
                    Musica updatedMusica = musicaService.save(musica);
                    return ResponseEntity.ok(updatedMusica);
                })
                .orElse(ResponseEntity.notFound().build());
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteMusica(@PathVariable Long id) {
        return musicaService.findById(id)
                .map(musica -> {
                    musicaService.deleteById(id);
                    return ResponseEntity.ok().build();
                })
                .orElse(ResponseEntity.notFound().build());
    }
    
    @GetMapping("/buscar")
    public ResponseEntity<List<Musica>> searchMusicas(
            @RequestParam(required = false) String titulo,
            @RequestParam(required = false) String artista,
            @RequestParam(required = false) String genero) {
        
        List<Musica> resultados;
        
        if (titulo != null && !titulo.trim().isEmpty()) {
            resultados = musicaService.findByTitulo(titulo);
        } else if (artista != null && !artista.trim().isEmpty()) {
            resultados = musicaService.findByArtista(artista);
        } else if (genero != null && !genero.trim().isEmpty()) {
            resultados = musicaService.findByGenero(genero);
        } else {
            resultados = musicaService.findAll();
        }
        
        return ResponseEntity.ok(resultados);
    }
    
    // Endpoint adicional para favoritar/desfavoritar
    @PatchMapping("/{id}/favorita")
    public ResponseEntity<Musica> toggleFavorita(@PathVariable Long id) {
        try {
            Musica musica = musicaService.toggleFavorita(id);
            return ResponseEntity.ok(musica);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    // Endpoint para listar favoritas
    @GetMapping("/favoritas")
    public ResponseEntity<List<Musica>> listarFavoritas() {
        List<Musica> favoritas = musicaService.findFavoritas();
        return ResponseEntity.ok(favoritas);
    }
}
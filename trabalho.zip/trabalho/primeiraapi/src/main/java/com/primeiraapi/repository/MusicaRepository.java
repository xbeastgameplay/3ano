package com.primeiraapi.repository;

import com.primeiraapi.model.Musica;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MusicaRepository extends JpaRepository<Musica, Long> {
    
    // Busca por artista (ignorando maiúsculas/minúsculas e contendo texto)
    List<Musica> findByArtistaContainingIgnoreCase(String artista);
    
    // Busca por título (ignorando maiúsculas/minúsculas e contendo texto)
    List<Musica> findByTituloContainingIgnoreCase(String titulo);
    
    // Busca por gênero (exato)
    List<Musica> findByGenero(String genero);
    
    // Busca por favoritas
    List<Musica> findByFavoritaTrue();
    
    // Métodos adicionais que podem ser úteis:
    List<Musica> findByAlbumContainingIgnoreCase(String album);
    
    List<Musica> findByArtista(String artista); // busca exata
    
    List<Musica> findByTitulo(String titulo); // busca exata
    
    // Busca por ano de lançamento
    List<Musica> findByAnoLancamento(Integer anoLancamento);
    
    // Busca por gênero ignorando case
    List<Musica> findByGeneroIgnoreCase(String genero);
}
import MusicaForm from "../components/MusicaForm";

function Cadastro() {
    return (
        <div>
            <h1>Cadastro de Música</h1>
            {/* Renderiza o formulário de música */}
            <MusicaForm />
        </div>
    );
}

export default Cadastro;
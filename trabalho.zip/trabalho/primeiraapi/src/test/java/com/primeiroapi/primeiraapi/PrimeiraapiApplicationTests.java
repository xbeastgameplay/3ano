package com.primeiroapi.primeiraapi;  // CORRIGIDO: mesmo pacote da aplicação

@SpringBootTest
class PrimeiraapiApplicationTests {

    @Test
    void contextLoads() {
    }

}
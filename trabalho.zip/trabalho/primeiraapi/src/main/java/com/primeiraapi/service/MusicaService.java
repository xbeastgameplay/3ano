package com.primeiraapi.service;

import com.primeiraapi.model.Musica;
import com.primeiraapi.repository.MusicaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;

@Service
public class MusicaService {
    
    @Autowired
    private MusicaRepository musicaRepository;
    
    public List<Musica> findAll() {
        return musicaRepository.findAll();
    }
    
    public Optional<Musica> findById(Long id) {
        return musicaRepository.findById(id);
    }
    
    public Musica findOrThrow(Long id) {
        return musicaRepository.findById(id)
             .orElseThrow(() ->
                new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "Música não encontrada com id: " + id
                ));
    }
    
    public Musica save(Musica musica) {
        return musicaRepository.save(musica);
    }
    
    public void deleteById(Long id) {
        musicaRepository.deleteById(id);
    }
    
    public List<Musica> findByArtista(String artista) {
        return musicaRepository.findByArtistaContainingIgnoreCase(artista);
    }
    
    public List<Musica> findByTitulo(String titulo) {
        return musicaRepository.findByTituloContainingIgnoreCase(titulo);
    }
    
    public List<Musica> findByGenero(String genero) {
        return musicaRepository.findByGenero(genero);
    }
    
    public List<Musica> findFavoritas() {
        return musicaRepository.findByFavoritaTrue();
    }
    
    public Musica toggleFavorita(Long id) {
        Optional<Musica> musicaOpt = musicaRepository.findById(id);
        if (musicaOpt.isPresent()) {
            Musica musica = musicaOpt.get();
            musica.setFavorita(!musica.isFavorita());
            return musicaRepository.save(musica);
        }
        throw new ResponseStatusException(
            HttpStatus.NOT_FOUND,
            "Música não encontrada com id: " + id
        );
    }
}